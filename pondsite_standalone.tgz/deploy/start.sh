#!/bin/sh
cd "$(dirname "$0")"
PORT=${PORT:-3205} NODE_ENV=production nohup node server.mjs > "$HOME/pondsite.log" 2>&1 &
echo "PondSite started, pid $!"
